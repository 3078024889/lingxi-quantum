#!/usr/bin/env node
/**
 * Fetch Wikipedia REST summaries → tongshi-global batch (proposition/event/evidence).
 * Usage: node fetch-wikipedia-batch.mjs [out.json]
 */
import { createHash } from "crypto";
import { writeFileSync, mkdirSync, existsSync } from "fs";
import { dirname, resolve } from "path";
import { fileURLToPath } from "url";

const __dirname = dirname(fileURLToPath(import.meta.url));
const root = resolve(__dirname, "..");

const TOPICS = [
  { title: "光速", discipline: "physics", lang: "zh" },
  { title: "线粒体", discipline: "biology", lang: "zh" },
  { title: "地球内部结构", discipline: "earth-science", lang: "zh" },
  { title: "太阳系", discipline: "astronomy", lang: "zh" },
  { title: "水", discipline: "chemistry", lang: "zh" },
  { title: "素数", discipline: "math", lang: "zh" },
  { title: "算法", discipline: "cs", lang: "zh" },
  { title: "机会成本", discipline: "economics", lang: "zh" },
  { title: "工作记忆", discipline: "psychology", lang: "zh" },
  { title: "印刷术", discipline: "history", lang: "zh" },
  { title: "DNA", discipline: "biology", lang: "zh" },
  { title: "相对论", discipline: "physics", lang: "zh" },
  { title: "板块构造论", discipline: "earth-science", lang: "zh" },
  { title: "黑洞", discipline: "astronomy", lang: "zh" },
  { title: "元素周期表", discipline: "chemistry", lang: "zh" },
  { title: "勾股定理", discipline: "math", lang: "zh" },
  { title: "操作系统", discipline: "cs", lang: "zh" },
  { title: "供需", discipline: "economics", lang: "zh" },
  { title: "注意力", discipline: "psychology", lang: "zh" },
  { title: "丝绸之路", discipline: "history", lang: "zh" },
  { title: "Speed of light", discipline: "physics", lang: "en" },
  { title: "Mitochondrion", discipline: "biology", lang: "en" },
  { title: "Prime number", discipline: "math", lang: "en" },
  { title: "Algorithm", discipline: "cs", lang: "en" },
  { title: "Photosynthesis", discipline: "biology", lang: "en" },
];

function sha256(s) {
  return createHash("sha256").update(s, "utf8").digest("hex");
}

function host(lang) {
  return lang === "en" ? "en.wikipedia.org" : "zh.wikipedia.org";
}

async function fetchSummary(title, lang) {
  const url = `https://${host(lang)}/api/rest_v1/page/summary/${encodeURIComponent(title)}`;
  const res = await fetch(url, {
    headers: {
      "User-Agent": "LingxiField-TongshiBot/1.0 (educational ingest; contact: lingxifield)",
      Accept: "application/json",
    },
  });
  if (!res.ok) throw new Error(`${title} HTTP ${res.status}`);
  return { url, data: await res.json() };
}

function toItem(topic, url, data, idx) {
  const extract = String(data.extract || "").replace(/\s+/g, " ").trim();
  if (extract.length < 40) return null;
  // first 1–2 sentences as proposition
  const sentences = extract.split(/(?<=[。．.!?？])\s+/).filter(Boolean);
  const proposition = sentences.slice(0, 2).join("").slice(0, 1000);
  const evidence = `Wikipedia summary · ${data.title || topic.title} · ${url}`.slice(0, 1200);
  const event_or_context = `开放百科摘要抽取 · lang=${topic.lang} · pageid=${data.pageid || ""}`.slice(0, 1200);
  const content_hash = sha256(`${topic.discipline}|${proposition}`);
  return {
    id: `tg-wiki-${String(idx).padStart(4, "0")}`,
    proposition,
    event_or_context,
    evidence,
    discipline: topic.discipline,
    tier: "bronze",
    confidence: 0.82,
    source_class: "open_encyclopedia",
    source_url: url,
    source_title: data.title || topic.title,
    content_hash,
  };
}

const outPath = resolve(process.argv[2] || `${root}/batches/batch-wiki-001.json`);
const items = [];
const errors = [];

for (let i = 0; i < TOPICS.length; i++) {
  const topic = TOPICS[i];
  try {
    const { url, data } = await fetchSummary(topic.title, topic.lang);
    if (data.type === "disambiguation") {
      errors.push({ title: topic.title, reason: "disambiguation" });
      continue;
    }
    const item = toItem(topic, data.content_urls?.desktop?.page || url, data, items.length + 1);
    if (!item) {
      errors.push({ title: topic.title, reason: "short_extract" });
      continue;
    }
    items.push(item);
    console.log(`[ok] ${topic.title} → ${item.proposition.slice(0, 40)}…`);
  } catch (e) {
    errors.push({ title: topic.title, reason: String(e.message || e) });
    console.error(`[fail] ${topic.title}:`, e.message || e);
  }
  await new Promise((r) => setTimeout(r, 350));
}

const batch = {
  batch: "wiki-001",
  fetched_at: new Date().toISOString(),
  source_seed: "sources/seed-sources-v1.json",
  counts: { ok: items.length, fail: errors.length, requested: TOPICS.length },
  errors,
  items,
};

mkdirSync(dirname(outPath), { recursive: true });
writeFileSync(outPath, JSON.stringify(batch, null, 2), "utf8");
console.log(`[done] ${items.length}/${TOPICS.length} → ${outPath}`);
