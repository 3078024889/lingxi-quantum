# Blocking And Causality

Use this reference for pursuit, restraint, combat, machinery, chained object
actions, or any scene where direction and physical connection determine whether
the result makes sense.

## Causal Chain

Resolve each complex action before writing prose:

```text
subject
-> start position
-> action and direction
-> target or physical connection
-> visible response
-> end position or state
```

Example:

```text
the man walks toward the bow
-> his right foot enters a rope loop
-> the loop tightens around his ankle
-> the rope runs across the deck to the caged animal
-> the woman kicks the cage door open
-> the animal runs toward the stern
-> the rope pulls backward
-> the man slides in the opposite direction from his original movement
```

## Spatial Questions

Answer only the questions that affect execution:

- Where does each active subject begin?
- Which direction does each subject move?
- What connects one object to another?
- Which hand, foot, or body part performs the plot-bearing action?
- What visible change proves that the action happened?
- Where does each active subject end?

Do not add decorative measurements or a full floor plan when the action is
simple.

## Storyboard Boundary

Keep a causal chain inside one storyboard when it fits the duration and model
complexity. When it must cross a storyboard boundary:

- End the first storyboard on a visible unfinished cause.
- Start the next storyboard on the matching physical result.
- Preserve direction, body orientation, object state, and connection.

Examples:

- End on a rope snapping taut; start on the ankle being pulled backward.
- End on a hand reaching for a spear; start on the same hand gripping it.
- End on a door beginning to open; start on the subject crossing the threshold.

## Failure Patterns

Reject or rewrite when:

- The result appears without a visible cause.
- A rope, weapon, door, vehicle, or body changes connection without explanation.
- A character moves in a direction incompatible with the force acting on them.
- Two subjects occupy contradictory positions.
- The prompt hides missing mechanics behind abstract transition words.
