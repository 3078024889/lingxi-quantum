# Demo Brief

Use this synthetic public brief for smoke testing the skill.

```text
Create a 30-second product ad for a smart desk lamp. The audience is remote workers.
The story starts with a tired designer working at night, then the lamp changes the mood
with warm adaptive light, and the final shot shows a calm desk setup before the logo.
Aspect ratio: 16:9.
Tone: cinematic, clean, gentle, premium.
```
