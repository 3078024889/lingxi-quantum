# Create Storyboard Skill

为 Image 2 与 SceneDance/Seedance 视频生成创建连续性优先的分镜制作包。

这个 skill 可以把剧本、广告创意、短剧概念、产品视频 brief 或场景想法，转成导演级制作包：bible、shot cards、clip plan、镜头接力矩阵、剪辑边界矩阵、Image 2 提示词、SceneDance 提示词、剪映/CapCut 剪辑说明和 image manifest。

## 输出内容

- 剧本分析与项目简报
- 角色、场景、道具/产品、风格和连续性 bible
- 默认 `SH### = CLIP###` 的 shot cards
- SceneDance 参考图输入矩阵
- 镜头接力矩阵与剪辑边界矩阵
- 中文与英文 Image 2 提示词
- SceneDance shot prompts 和 usage list
- 后期、剪映/CapCut、风险、备用方案和 image manifest

## 复现运行画像

内置 scaffold 脚本是确定性的，不需要 AI 模型。真正做高质量分镜制作包时，难点在于连续性设计、镜头接力、参考图纪律、提示词写作和 QA，因此需要能力足够强的 agent 运行环境。

推荐运行环境：

- Codex 风格 agent mode，能读写本地文件并执行命令。
- 任务涉及图片、角色设定图、关键帧或分镜图时，使用支持图片输入的多模态模型。
- 长剧、多场景连续性或高价值制作任务，建议使用 GPT-5.5 或同级 frontier reasoning model。
- reasoning effort：常规生产任务用 `high`；多场景连续性、复杂接力设计或双语提示词制作在可用时用 `xhigh`。
- 上下文长度足够同时检查剧本 brief、bible、shot cards、参考矩阵、生成图和剪辑说明。

作者已验证环境：macOS、Codex 本地 agent、GPT-5.5 级别 reasoning model，复杂制作包使用 `xhigh` reasoning。较小模型也能使用 scaffold，但连续性、接力逻辑和提示词一致性通常需要更多人工修正。

## 快速开始

在仓库根目录生成制作包骨架：

```bash
python3 skills/create-storyboard/scripts/create_storyboard_package.py demo-product-ad \
  --root outputs \
  --title "Demo Product Ad" \
  --duration "30s" \
  --aspect "16:9" \
  --video-type "product ad"
```

输出目录：

```text
outputs/storyboard_projects/demo-product-ad/
```

## 平台说明

这个仓库主要在 macOS 上编写和验证。scaffold 脚本只使用 Python 标准库，跨平台可运行。

- macOS/Linux/WSL2：可以直接使用 README 中的命令。
- Windows PowerShell：用 `py` 代替 `python3`，并使用反引号换行或改成单行命令。
- 建议使用 Python 3.10+。
- 如果工作流还包含图像生成、视频生成或本地媒体工具，请在目标操作系统上单独验证这些工具。

## Skill 安装

可复用 agent skill 位于：

```text
skills/create-storyboard/SKILL.md
```

Codex 本地安装时，复制 `skills/create-storyboard/` 到本地 skills 目录后重启 agent。

单独安装后的 skill 目录也能跑最小 smoke test：

```bash
cd ~/.codex/skills/create-storyboard
python3 scripts/create_storyboard_package.py demo-storyboard \
  --root outputs \
  --title "Demo Storyboard" \
  --duration "30s" \
  --aspect "16:9"
```

Agent runtime 与系统平台说明见 `skills/create-storyboard/references/runtime-and-platform.md`。

## 设计原则

核心链路是：

```text
剧本或创意 -> 连续性 bible -> shot cards -> 接力/剪辑矩阵 -> prompts -> 生成图/视频 -> 剪辑计划
```

分镜图主要用于审阅和参考。SceneDance/Seedance 主输入优先使用干净 keyframe。最终生产分镜板应由干净 panel/keyframe 和项目元数据确定性排版生成，不应直接接受图片模型生成的带文字 board layout。

## 状态

这是一个工作中 Codex skill 的开源包装版本。确定性的 scaffold 路径已包含；图像和视频生成仍取决于用户选择的工具、模型和运行权限。
