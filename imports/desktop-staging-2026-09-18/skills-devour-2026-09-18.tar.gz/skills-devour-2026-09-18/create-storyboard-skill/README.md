# Create Storyboard Skill

Create continuity-first storyboard production packages for Image 2 and SceneDance/Seedance video generation.

This skill turns a script, ad idea, short-drama concept, product video brief, or scene outline into a director-grade production package: bibles, shot cards, clip plans, handoff matrices, edit boundary plans, Image 2 prompts, SceneDance prompts, CapCut/Jianying edit notes, and image manifests.

## What It Produces

- Script analysis and project brief.
- Character, scene, prop/product, style, and continuity bibles.
- Shot cards with one `SH###` per default `CLIP###`.
- SceneDance reference input matrix.
- Handoff design and edit boundary matrices.
- Chinese and English Image 2 prompts.
- SceneDance shot prompts and usage list.
- Post-edit, Jianying/CapCut, risk, fallback, and image manifest files.

## Reproducibility Profile

The scaffold script is deterministic and does not require an AI model. Production-quality storyboard planning does require a capable agent runtime because the hard work is continuity design, shot handoff planning, visual reference discipline, prompt writing, and QA.

Recommended agent runtime:

- Codex-style agent mode with local file read/write and command execution.
- Multimodal model when images, character sheets, keyframes, or storyboard boards are part of the task.
- Frontier reasoning model, such as GPT-5.5 or an equivalent model, for long-form drama, complex continuity, or high-value production work.
- Reasoning effort: `high` for normal production work; `xhigh` when available for multi-scene continuity, dense handoff design, or bilingual prompt packages.
- Long enough context to inspect script briefs, bibles, shot cards, reference matrices, generated images, and edit notes together.

Known-good author setup: macOS, Codex-style local agent, GPT-5.5-class reasoning, and `xhigh` reasoning for complex packages. Smaller models can still use the scaffold, but may need more human correction for continuity, handoff logic, and prompt consistency.

## Quick Start

Create a package skeleton from the repository root:

```bash
python3 skills/create-storyboard/scripts/create_storyboard_package.py demo-product-ad \
  --root outputs \
  --title "Demo Product Ad" \
  --duration "30s" \
  --aspect "16:9" \
  --video-type "product ad"
```

The command writes a complete template package under:

```text
outputs/storyboard_projects/demo-product-ad/
```

## Platform Notes

The repository is authored and validated primarily on macOS. The scaffold script uses only the Python standard library and is cross-platform.

- macOS/Linux/WSL2: use the commands as written.
- Windows PowerShell: use `py` instead of `python3`, and use backticks or single-line commands instead of POSIX backslash continuations.
- Python 3.10+ is recommended.
- If the workflow also includes image generation, video generation, or local media tooling, validate those tools separately on the target OS.

## Skill

The reusable agent skill lives at:

```text
skills/create-storyboard/SKILL.md
```

For Codex-style local installation, copy `skills/create-storyboard/` into your local skills directory and restart the agent.

The installed skill folder is self-contained for a smoke test:

```bash
cd ~/.codex/skills/create-storyboard
python3 scripts/create_storyboard_package.py demo-storyboard \
  --root outputs \
  --title "Demo Storyboard" \
  --duration "30s" \
  --aspect "16:9"
```

Read `skills/create-storyboard/references/runtime-and-platform.md` for agent runtime and OS notes.

## Design Principle

The important boundary is:

```text
script or concept -> continuity bibles -> shot cards -> handoff/edit matrices -> prompts -> generated images/video -> edit plan
```

Storyboard boards are review and reference artifacts. Clean keyframes are the preferred primary inputs for SceneDance/Seedance. Final production boards should be assembled deterministically from clean panels/keyframes and project metadata, not accepted as raw AI-generated board layouts.

## Status

This repository is an open-source packaging pass over a working local Codex skill. The deterministic scaffold path is included; image and video generation remain dependent on the user's chosen tools and model/runtime access.
