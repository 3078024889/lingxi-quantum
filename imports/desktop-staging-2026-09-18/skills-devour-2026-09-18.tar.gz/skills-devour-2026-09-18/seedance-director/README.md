<p align="center">
  <a href="README.md">English</a> | <a href="README_zh.md">中文</a>
</p>

# seedance-director

> AI video director for the Seedance (即梦) platform. Idea in, production-ready prompts out.

An [Agent Skill](https://agentskills.io) that guides you from a rough idea through asset preparation, storyboarding, and prompt generation — all inside Claude Code.

## Install

```bash
npx skills add https://github.com/crowscc/seedance-director
```

Then describe your video idea. Activates on keywords like "Seedance", "即梦", "storyboard", "分镜", "运镜", etc.

## See It in Action

```
You: I want a 15-second coffee product video for Xiaohongshu. Cozy vibe.

Director: [AskUserQuestion] Which narrative structure fits best?
          > AIDA — attention → interest → desire → action, classic for product ✓
          > Daily Slice — a moment in life, natural and relatable
          > Custom — describe your own

You: AIDA

Director: [AskUserQuestion] Missing product reference. Generate?
          > ✅ Generate reference images
          > ⏭ Skip, go straight to prompts

You: Skip

Director:
  Storyboard (single, 9:16, Japanese fresh style):
    001 | 0-2s  | POV          | Handheld Push | Hand pushes open café door, warm light
    002 | 2-4s  | Close-Up     | Handheld      | Product on table, shallow DOF
    003 | 4-6s  | Macro CU     | Slow Push In  | Surface detail, light spots
    004 | 6-8s  | Medium Shot  | Handheld      | Using product, natural interaction
    ...

  Seedance prompt (paste directly):
    ## Characters + References
    @Image1 as product reference

    ## Background
    A warm afternoon in a sunlit café...

    ## Shot Descriptions
    Shot 1 (0-2s): POV, hand pushes open glass door, handheld, slight shake
    Shot 2 (2-4s): Close-up, product on wooden table, window light
    ...

    ## Sound Design
    BGM: Light acoustic guitar, warm and relaxed
    Ambient: Café chatter, cup clinks, door chime
    Narration — Shot 1: "Every morning starts with this warmth." Shot 3: "One cup. Simple as that."
    Voice ref: Young female voice, light and natural

    ## Style Directives
    Japanese fresh, soft natural light, warm tones, shallow DOF

    ## Negatives
    No text, watermarks, logos

  [Operation guide: asset prep → generation params → segment connection → review checklist]
```

## Workflow

<p align="center">
  <img src="assets/workflow_en.svg" alt="seedance-director workflow" width="700">
</p>

### Phase 1-2: Understand & Dig

Scans your input for 5 dimensions: **topic**, **duration**, **style**, **assets**, **audio**.

Missing info gets filled via `AskUserQuestion` — options are **dynamically ranked** by relevance (priority: topic > narrative structure > style > duration > assets > audio). Say "coffee ad" and narrative structures like "Contrast" and "AIDA" get prioritized over "Suspense." Up to 3 rounds; remaining dimensions auto-decided.

Narrative structure is **always discussed** even when most dimensions are clear.

### Phase 3: Asset Preparation (Normal / Pro Mode)

Runs in **Normal mode** by default (skips frame generation, goes straight to storyboard). **Pro mode** (full per-shot reference frames) only activates when you explicitly ask for it.

**Normal mode** checks what visual references you have:

- **Have character references?** → Skip Phase 3 entirely
- **Missing references?** → Generate character turnaround sheets only, then proceed

**Pro mode** (on request): generates complete composition frames for every key shot — character (@reference) + background + on-screen text elements — for precise visual control.

Multiple assets are generated in **parallel** via subagents.

**Fast track**: If you provide both character references AND a complete storyboard table, Phase 2 (storyboard design) and Phase 4 (user confirmation) are skipped — straight to prompt generation.

### Phase 4: Storyboard

Generates a professional shot-by-shot storyboard (shot sizes and camera moves in both Chinese and English).

**Texture-feel decision** happens here — based on content type, platform, and your chosen style, the director decides between **realistic life feel** (handheld, natural light, micro-actions) and **polished production feel** (stabilized, studio lighting, precise framing). Your explicit style choice always overrides platform defaults.

**Each Seedance generation is fixed at 15s.** Every prompt = one 15s clip containing multiple shots (e.g., Shot 1: 0-3s → Shot 2: 3-7s → Shot 3: 7-12s → Shot 4: 12-15s). Multi-segment videos are connected via Seedance's built-in capabilities — no external editing software.

For multi-segment videos, **video extension is the default** — it produces the most natural BGM/audio/visual continuity:

| Priority | Strategy | When to use |
|----------|----------|-------------|
| **Default** | **Video extension** (chain) | Most cases. BGM/voice/visuals stay seamless |
| Fallback | **Independent + first-frame ref** | Full scene jump, or need to redo one segment without affecting others |
| Special | **Fully independent** | Montage, style switch |

**Chain dependency note**: video extension is sequential (seg 1 → extend to seg 2 → extend to seg 3). If segment N is unsatisfactory, segment N+1 and beyond must be regenerated. Generate 2-3 versions per segment, pick the best, then extend.

Storyboard is confirmed via `AskUserQuestion` before moving on.

### Phase 5: Prompts + Operation Guide

Converts confirmed storyboard into **copy-paste-ready prompts** for Seedance. Every prompt follows a fixed **six-section structure**:

```
## Characters + References
  Character A: @Image1 — [appearance description]
  Scene ref:   @Image3 — [environment description]

## Background
  [Context, environment, emotional atmosphere]

## Shot Descriptions
  Shot 1 (0-3s): [shot size], [content], Character A: "dialogue", [camera move]

## Sound Design
  BGM: [style / instruments / rhythm changes]
  Ambient: [time-stamped sound effects]
  Dialogue/Narration (one or both, full script required):
    - Dialogue: written in Shot Descriptions — Character A: "full line" (Seedance auto-syncs lip movement)
    - Narration: full script per shot — "Shot 1: 'The street holds the city's deepest warmth.'"
    - Voice ref: [timbre and tone]

## Style Directives
  [Unified look: texture, color tone, lighting, depth of field]

## Negatives
  No text, watermarks, logos
```

Single-segment outputs 1 recommended version + operation guide with adjustable directions. Multi-segment outputs one prompt per segment with connection guides.

**All audio (BGM, ambient, dialogue, narration) is generated directly by Seedance** — no post-production audio work. The operation guide only covers in-platform steps; prohibited steps include adding voiceover tracks, importing to editing software, or any TTS dubbing.

After prompts, the director collects feedback via `AskUserQuestion` — adjust specific shots, swap styles, or generate variants — until you're satisfied.

## Project Structure

```
skills/seedance-director/
├── SKILL.md                          # Core workflow engine (~400 lines)
├── references/
│   ├── platform-capabilities.md      # 10 Seedance modes + tech specs + @reference rules
│   ├── narrative-structures.md       # 16 narrative structures with timing & selection guide
│   ├── scene-strategies.md           # 6 scene-type strategies with full prompt examples
│   └── vocabulary.md                 # Camera + visual style bilingual vocabulary
├── templates/
│   ├── single-video.md               # 5 storyboard templates (A-E)
│   ├── multi-segment.md              # Multi-segment templates for 30s/45s/60s+
│   └── scene-templates.md            # E-commerce / Xianxia / Drama / Education / MV / Short-video
└── examples/
    ├── single-examples.md            # 6 complete single-segment examples
    └── multi-examples.md             # 4 complete multi-segment examples
```

References are loaded on demand — the core SKILL.md stays lean.

## Acknowledgments

Inspired by:

- [songguoxs/seedance-prompt-skill](https://github.com/songguoxs/seedance-prompt-skill)
- [elementsix/elementsix-skills](https://github.com/elementsix/elementsix-skills)

## License

MIT
