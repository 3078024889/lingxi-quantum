import type { Metadata } from "next";
import Nav from "@/components/Nav";
import Footer from "@/components/Footer";
import HomeProblemHub from "@/components/HomeProblemHub";

export const metadata:Metadata={
  title:"灵犀场｜免费实用工具 · AI 创作 · 一念显化",
  description:"一个让想法被理解、让问题被处理、让结果真正发生的场智能数字空间。免费实用工具、AI 创作与构建、探索与显化，一键即达，一念显化。",
  alternates:{canonical:"/"}
};

export default function Home(){
  return <>
    <Nav/>
    <HomeProblemHub/>
    <Footer/>
  </>;
}
