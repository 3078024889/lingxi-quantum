import { NextResponse } from "next/server";
import { alipayEnabled, alipayMissingVars } from "@/lib/alipay";
import { wechatPayConfigured, wechatPayMissingVars } from "@/lib/wechatpay";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

function paypalAvailable() {
  return Boolean(
    process.env.PAYPAL_CLIENT_ID?.trim() &&
    process.env.PAYPAL_CLIENT_SECRET?.trim()
  );
}

export async function GET() {
  const wechat = wechatPayConfigured();
  const alipay = alipayEnabled();
  const paypal = paypalAvailable();

  return NextResponse.json(
    {
      wechat,
      alipay,
      paypal,
      diagnostics: {
        wechat: {
          configured: wechat,
          missing: wechat ? [] : wechatPayMissingVars(),
        },
        alipay: {
          configured: alipayMissingVars().length === 0,
          enabled: alipay,
          missing: alipayMissingVars(),
        },
        paypal: {
          configured: paypal,
          missing: paypal
            ? []
            : ["PAYPAL_CLIENT_ID", "PAYPAL_CLIENT_SECRET"].filter(
                (name) => !process.env[name]?.trim()
              ),
        },
      },
    },
    {
      headers: {
        "Cache-Control": "no-store, max-age=0",
      },
    }
  );
}
